// Get the login button
var loginBtn = document.getElementById("loginBtn");

// Add an event listener for when the login button is clicked
loginBtn.addEventListener("click", function() {
	// Replace the URL below with the desired page's URL
	window.location.href = "login.html";
});
