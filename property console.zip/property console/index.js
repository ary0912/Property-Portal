	function adminLogin() {
			// TODO: Add admin login logic
			alert("Admin login clicked!");
		}
		
		function userLogin() {
			// TODO: Add user login logic
			alert("User login clicked!");
		}